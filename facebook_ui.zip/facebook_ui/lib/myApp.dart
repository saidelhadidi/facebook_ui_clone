import 'package:facebook_ui/items/friends_story_card.dart';
import 'package:facebook_ui/items/post.dart';
import 'package:facebook_ui/screens/home_screen.dart';
import 'package:facebook_ui/screens/login_screen.dart';
import 'package:facebook_ui/screens/splash_screen.dart';
import 'package:flutter/material.dart';

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: LoginScreen(),
      // HomeScreen(),
      // Post(),
      // const SplashScreen(),
    );
  }
}
